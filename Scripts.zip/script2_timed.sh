#!/bin/bash

SCRIPT_DIR=$(dirname "$(readlink -f "$0")")

#garantir que um caminho passado como argumento seja convertido para caminho absoluto, mas apenas se for um caminho local.
resolve_path_if_local() {
    if [[ "$1" == /* || "$1" == ./* ]]; then
        readlink -f "$1"
    else
        echo "$1"
    fi
}

#casos de "java", "node", c#, php
COMANDO=()
if [ $# -ge 1 ]; then
    if [[ "$1" == "java" ]]; then
        COMANDO+=("java" "-cp" "$SCRIPT_DIR" "$2")
        shift 2
    elif [[ "$1" == "node" ]]; then
        #força caminho absoluto do script JS
        COMANDO+=("node" "$SCRIPT_DIR/$2")
        shift 2
    elif [[ "$1" == "php" ]]; then
        #força caminho absoluto do script PHP
        COMANDO+=("php" "$SCRIPT_DIR/$2")
        shift 2
    elif [[ "$1" == "dotnet" ]]; then
        COMANDO+=("dotnet")
        shift

        while [[ "$1" != "--" && $# -gt 0 ]]; do
            if [[ "$1" == "--project" ]]; then
                COMANDO+=("$1")
                shift
                PROJ_PATH="$1"
                if [[ "$PROJ_PATH" == /* || "$PROJ_PATH" == ./* ]]; then
                    ABS_PROJ_PATH=$(readlink -f "$PROJ_PATH")
                else
                    ABS_PROJ_PATH="$SCRIPT_DIR/$PROJ_PATH"
                fi
                COMANDO+=("$ABS_PROJ_PATH")
                shift
            else
                COMANDO+=("$1")
                shift
            fi
        done

        if [[ "$1" == "--" ]]; then
            COMANDO+=("--")
            shift
        fi
    else
        COMANDO+=("$(resolve_path_if_local "$1")")
        shift
    fi
fi

#add os argumentos restantes
COMANDO+=("$@")
#pastas e prefixos
pastas=("aleatorios" "decrescentes" "ordenados" "parcialmenteOrdenados")
prefixos=("a" "d" "o" "po")

#for para trocar de pastas
for i in "${!pastas[@]}"; do
    pasta="${pastas[$i]}"
    prefixo="${prefixos[$i]}"

    cd "$pasta"

    #for para trocar de arquivos
    for arquivo in $(ls ${prefixo}*.txt | sort -V); do
        #for para iteracao
        for j in $(seq 1 30); do

            "${COMANDO[@]}" "$arquivo" "$SCRIPT_DIR"

        done
    done

    cd ..
done

