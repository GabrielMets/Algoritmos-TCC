#!/bin/bash

#CPP
g++ sort_cpp_timed.cpp -o sort_cpp_timed -std=c++17
./script2_timed.sh ./sort_cpp_timed

#python
./script2_timed.sh python3 ../sort_py_timed.py

#C
gcc -o sort_c_timed sort_c_timed.c
./script2_timed.sh ./sort_c_timed

#Java
javac sort_java_timed.java
./script2_timed.sh java sort_java_timed

#JavaScript
./script2_timed.sh node sort_js_timed.js

#TypeScript
tsc sort_ts_timed.ts
./script2_timed.sh node sort_ts_timed.js

#Golang
go build -o sort_go_timed sort_go_timed.go
./script2_timed.sh ./sort_go_timed

#Rust
rustc sort_rust_timed.rs -o sort_rust_timed
./script2_timed.sh ./sort_rust_timed

#PHP
./script2_timed.sh php sort_php_timed.php

#C#
#dotnet new console -n OrdenacaoTemporizada
#cd OrdenacaoTemporizada/
#dotnet build
#cd ..
./script2_timed.sh dotnet run --project OrdenacaoTemporizada --



